minetest.register_node("cyan_blocks:cyan_block", {
        description = "Cyan Block",
        tiles = {"cyan_concrete.png"},
        groups = {cracky = 3},
})