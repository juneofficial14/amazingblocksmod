minetest.register_node("green_blocks:green_block", {
        description = "Green Block",
        tiles = {"greenblock.png"},
        groups = {cracky = 3},
}) 