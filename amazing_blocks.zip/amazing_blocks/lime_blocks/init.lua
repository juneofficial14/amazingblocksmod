minetest.register_node("lime_blocks:lime_block", {
        description = "Lime Block",
        tiles = {"lime_block.png"},
        groups = {cracky = 3},
})