minetest.register_node("red_blocks:red_block", {
        description = "Red Block",
        tiles = {"red_block.png"},
        groups = {cracky = 3},
})